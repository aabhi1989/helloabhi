function Result(first, second, third){
    this.first = first;
    this.second = second;
    this.third = third;
}

module.exports = Result;

